!#/bin/bash

$MATIEC_FLDR/iec2c $1 -I $MATIEC_FLDR/lib 
